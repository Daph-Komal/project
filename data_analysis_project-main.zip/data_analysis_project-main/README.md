# data_analysis_project
demo projects 
Hands_on experiance
BY using Pwoer BI, EXCEL, python.
